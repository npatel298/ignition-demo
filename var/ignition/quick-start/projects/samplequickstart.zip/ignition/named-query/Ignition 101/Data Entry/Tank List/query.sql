SELECT 
tankNo, tankName, tankType, tankVol, tankMaxVol, tankInUse
FROM tank
