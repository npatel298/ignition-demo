INSERT INTO tank (tankNo, tankName, tankType, tankVol, tankMaxVol, tankInUse)
VALUES (:tankNo, :tankName, :tankType, :tankVol, :tankMaxVol, :tankInUse)