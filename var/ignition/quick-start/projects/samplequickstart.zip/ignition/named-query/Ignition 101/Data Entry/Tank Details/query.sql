SELECT 
tankNo, tankName, tankType, tankVol, tankMaxVol, tankInUse
FROM tank
WHERE tankNo = :tankNo